"""road_main URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from . import views
urlpatterns = [
    path('',views.user_home,name='user_home'),
    path('m_home',views.m_home,name='m_home'),
    path('signin',views.signin,name='signin'),
    path('signup',views.signup,name='signup'),
    path('maintenance_page1',views.maintenance_page1,name='maintenance_page1'),
    path('Logout',views.Logout,name='Logout'),
    path('form1_submit',views.form1_submit,name='form1_submit'),
    path('maintenance_page2',views.maintenance_page2,name="maintenance_page2"),
    path('form2_submit',views.form2_submit,name='form2_submit'),
    path('user_page1',views.user_page1,name='user_page1'),
    path('contactus_form',views.contactus_form,name='contactus_form'),
]