from datetime import date
a = date(0000,00,00)
print(a)
print(type(a))