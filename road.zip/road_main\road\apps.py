from django.apps import AppConfig


class RoadConfig(AppConfig):
    name = 'road'
