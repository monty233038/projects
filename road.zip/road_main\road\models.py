from django.db import models

# Create your models here.
class data(models.Model):
    s_choices = [
        ('started','started'),
        ('inprogress','inprogress'),
        ('completed','completed'),
    ]
    main_id = models.CharField(max_length=20)
    main_by = models.CharField(max_length=30)
    road  = models.CharField(max_length=20)
    status = models.CharField(max_length=25,choices=s_choices,default='1')
    budget = models.CharField(max_length=40)
    distance = models.CharField(max_length=40)
    no_of_wrkr = models.CharField(max_length=10)
    proof = models.ImageField(upload_to='pics/')
    s_date = models.DateField(null=True)
    e_e_date = models.DateField(null=True)
    e_date =  models.DateField(null=True)
    n_date = models.DateField(null=True)
class contact_us(models.Model):
    name = models.CharField(max_length=30)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=10)
    message = models.TextField(max_length=200)

