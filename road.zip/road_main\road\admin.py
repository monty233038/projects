from django.contrib import admin
from road.models import data
from django.contrib.auth.models import User

# Register your models here.
admin.site.register(data)

